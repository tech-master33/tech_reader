import comtypes.client
from comtypes import COMError
import pythoncom
import threading
import queue

class Sapi5Driver:
    def __init__(self):
        self.voice = None
        self._init_engine()

    def _init_engine(self):
        try:
            # SAPI5 COM object
            self.voice = comtypes.client.CreateObject("SAPI.SpVoice")
        except Exception as e:
            print(f"Error initializing SAPI5: {e}")
            self.voice = None

    def speak(self, text, async_mode=True):
        if not self.voice:
            return
        
        try:
            # SVSFDefault = 0, SVSFlagsAsync = 1, SVSFPurgeBeforeSpeak = 2
            flags = 0
            if async_mode:
                flags |= 1
            # NVDA uses PurgeBeforeSpeak to interrupt
            flags |= 2 
            self.voice.Speak(text, flags)
        except COMError as e:
            print(f"SAPI5 Speak error: {e}")
            # Try to re-init on error
            self._init_engine()

    def stop(self):
        if self.voice:
            # Purge pending speech
            self.voice.Speak("", 2)

def tts_worker(text_queue):
    print("TTS worker starting...")
    pythoncom.CoInitialize()
    
    driver = Sapi5Driver()
    
    while True:
        text = text_queue.get()
        if text is None: break
        
        try:
            print(f"TTS speaking: {text}")
            driver.speak(text)
            print("TTS finished.")
        except Exception as e:
            print(f"Error in TTS speaking: {e}")
            
        text_queue.task_done()
    
    pythoncom.CoUninitialize()
