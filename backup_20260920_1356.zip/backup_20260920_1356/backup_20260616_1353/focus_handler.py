import comtypes
from comtypes import COMObject
import comtypes.gen.UIAutomationClient as UIA

class FocusChangedHandler(COMObject):
    _com_interfaces_ = [UIA.IUIAutomationFocusChangedEventHandler]

    def __init__(self, callback):
        self.callback = callback

    def HandleFocusChangedEvent(self, sender):
        try:
            # sender is the element that received focus
            # We need to cast it to UIA.IUIAutomationElement
            element = sender.QueryInterface(UIA.IUIAutomationElement)
            name = element.CurrentName
            if name:
                self.callback(name)
        except Exception as e:
            print(f"Error in focus event handler: {e}")
