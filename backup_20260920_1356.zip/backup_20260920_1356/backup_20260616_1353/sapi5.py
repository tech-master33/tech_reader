import comtypes.client
from comtypes import COMError
from synth_driver import SynthDriver

class Sapi5SynthDriver(SynthDriver):
    def __init__(self):
        self.voice = None
        self._init_engine()

    def _init_engine(self):
        try:
            self.voice = comtypes.client.CreateObject("SAPI.SpVoice")
        except Exception as e:
            print(f"Error initializing SAPI5: {e}")
            self.voice = None

    def speak(self, text):
        if not self.voice:
            return
        
        try:
            # SVSFlagsAsync = 1, SVSFPurgeBeforeSpeak = 2
            flags = 1 | 2
            self.voice.Speak(text, flags)
        except COMError as e:
            print(f"SAPI5 Speak error: {e}")
            self._init_engine()

    def stop(self):
        if self.voice:
            # Purge pending speech
            self.voice.Speak("", 2)
