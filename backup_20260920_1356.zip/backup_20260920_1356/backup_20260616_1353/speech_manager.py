import threading
import queue
import pythoncom
from sapi5 import Sapi5SynthDriver

class SpeechManager:
    def __init__(self):
        self.driver = Sapi5SynthDriver()
        self.text_queue = queue.Queue()
        self.worker_thread = threading.Thread(target=self._worker, daemon=True)
        self.worker_thread.start()

    def _worker(self):
        pythoncom.CoInitialize()
        while True:
            text = self.text_queue.get()
            if text is None: break
            self.driver.speak(text)
            self.text_queue.task_done()
        pythoncom.CoUninitialize()

    def speak(self, text):
        self.text_queue.put(text)

    def cancelSpeech(self):
        self.driver.stop()
        # Clear queue
        while not self.text_queue.empty():
            try:
                self.text_queue.get_nowait()
                self.text_queue.task_done()
            except queue.Empty:
                break
