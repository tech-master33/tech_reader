from comtypes import client
import comtypes.gen.UIAutomationClient as UIA
import pythoncom
import threading
import keyboard
import sys
from speech_manager import SpeechManager
from focus_handler import FocusChangedHandler

def main():
    print("Screenreader starting...")
    pythoncom.CoInitialize()
    
    # Initialize UIA COM object
    uia = client.CreateObject(UIA.CUIAutomation)
    
    speech_manager = SpeechManager()

    # Set up interruption hotkey (Ctrl)
    # Using 'ctrl' might interfere with other things.
    # We must ensure this hotkey is processed as quickly as possible.
    keyboard.add_hotkey('ctrl', speech_manager.cancelSpeech, suppress=False)
    print("Hotkeys registered: Ctrl to stop.")

    def on_focus_changed(name):
        safe_name = name.encode('utf-8', errors='ignore').decode('utf-8')
        print(f"Focused element changed to: {safe_name}")
        sys.stdout.flush()
        speech_manager.speak(safe_name)

    # Register event handler
    handler = FocusChangedHandler(on_focus_changed)
    uia.AddFocusChangedEventHandler(None, handler)

    print("Monitoring focus events...")

    # Keep the thread running to process events
    try:
        pythoncom.PumpMessages()
    except KeyboardInterrupt:
        pass
    finally:
        uia.RemoveAllEventHandlers()
        pythoncom.CoUninitialize()

if __name__ == "__main__":
    main()
