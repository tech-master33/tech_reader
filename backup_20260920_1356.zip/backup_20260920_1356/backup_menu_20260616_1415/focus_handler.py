import comtypes
from comtypes import COMObject
import comtypes.gen.UIAutomationClient as UIA

class FocusChangedHandler(COMObject):
    _com_interfaces_ = [UIA.IUIAutomationFocusChangedEventHandler]

    def __init__(self, callback):
        self.callback = callback

    def HandleFocusChangedEvent(self, sender):
        try:
            element = sender.QueryInterface(UIA.IUIAutomationElement)
            
            # Helper to get description
            def get_element_desc(el):
                try:
                    name = el.CurrentName
                    control_type = el.CurrentLocalizedControlType
                    auto_id = el.CurrentAutomationId
                    parts = []
                    if name: parts.append(name)
                    if control_type: parts.append(control_type)
                    if auto_id: parts.append(f"({auto_id})")
                    return " ".join(parts)
                except:
                    return ""

            full_description = get_element_desc(element)

            # If it's a list or tree and name is empty, try to get the selected item
            control_type_id = element.CurrentControlType
            if not full_description and control_type_id in (UIA.UIA_ListControlTypeId, UIA.UIA_TreeControlTypeId):
                # Try to get selection
                try:
                    selection_pattern = element.GetCurrentPattern(UIA.UIA_SelectionPatternId).QueryInterface(UIA.IUIAutomationSelectionPattern)
                    selected_items = selection_pattern.CurrentSelection
                    if selected_items.Length > 0:
                        selected_item = selected_items.GetElement(0)
                        full_description = get_element_desc(selected_item)
                except Exception:
                    pass

            if full_description:
                self.callback(full_description)
        except Exception:
            pass
